import java.io.*;
import java.util.*;
//Programmer: Julio Cinci
//Creates a pokemon object, used heavily in the PokemonArena function. Has everything about a pokemon taken straight fromt the resource
class Pokemon{
  double hp, energy, attack1dam, attack1cost, attack2dam, attack2cost, attackcount;//stuff that can be displayed as simple integers
  String name, type, weak, resist, attack1, attack2, attack1effect, attack2effect;//stuff that has to be displayed as a string
  
  
  public Pokemon(String info){
    String []stats = info.split(",");//takes the file and splits it off by the commas, allowing each individual stat to be accessed
    name = stats[0];
    hp= Double.parseDouble(stats[1]);
    type=stats[2];
    weak=stats[4];
    resist=stats[3];
    attackcount=Double.parseDouble(stats[5]);
    if (Double.parseDouble(stats[5])==2){
      attack1=stats[6];
      attack1dam=Double.parseDouble(stats[8]);
      attack1cost=Double.parseDouble(stats[7]);
      attack1effect=stats[9];
      attack2=stats[10];
      attack2dam=Double.parseDouble(stats[12]);
      attack2cost=Double.parseDouble(stats[11]);
      attack2effect=stats[13];
  }
    else{
      attack1=stats[6];
      attack1dam=Double.parseDouble(stats[8]);
      attack1cost=Double.parseDouble(stats[7]);
      attack1effect=stats[9];
    }
  }
  public String toString(){//allows toString() to be used with pokemon objects
    return name;//and makes the function return their names
  }
}