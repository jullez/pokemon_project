//Programmer: Julio Cinci
//Simulates an incredibly difficult game of pokemon, that is extremely stacked against you. As a player you can select 4 out of the 28 available pokemon to use in your party, with up to 2 attacks each
//some of those having special effects. If you don't have that as a preset, make your interactions pannel bigger so you can see all the information. Or pop it out, that works too
import java.util.*;
import java.io.*;
class PokemonArena{
  static ArrayList<Pokemon>allpoke = new ArrayList<Pokemon>();//array list that will hold all the 28 pokemon until the game starts
  static ArrayList<Pokemon>team = new ArrayList<Pokemon>();//array list that holds all your party pokemon
  
  
  public static void main(String[]args) throws IOException{
    Scanner kb=new Scanner(System.in);//keyboard functions that allows users to write responses to prompts
    Scanner poke=new Scanner(new BufferedReader(new FileReader("pokemon.txt")));//reads from the provided text file
    int n = Integer.parseInt(poke.nextLine());//gets the number at the top of the text file, 28
    
    for(int i=0; i<n; i++){
      allpoke.add(new Pokemon(poke.nextLine()));//starts adding each pokemon into the array. These pokemon are part of a separate object made in another file. i go more  into depth in said file (included in the zip, called Pokemon.java)
    }
    int arraycount=0;
    int[] pokemonpos=new int[4];//temporary array
    for (int i=0;i<4;i++){
      int apsize=allpoke.size();//use to shorten allpoke.size()
      for (int j=0; j<apsize;j++){
        System.out.print((j+1)+". "+allpoke.get(j)+", ");//prints every pokemon's name with their respective number 
      }
      System.out.println("Select your pokemon!");
      int choice=Integer.parseInt(kb.nextLine());//first instance of kb being used, selects a pokemon from the list
      if (choice<=apsize && choice>0){
        team.add(allpoke.get(choice-1));//since the pokemon list that's printed off starts at 1 instead of 0, this gets the user's "real" choice
        pokemonpos[arraycount]=(allpoke.indexOf(choice));//and adds it to the temporary array
        allpoke.remove(team.get(i));//and removes it from the allpoke array
      }
      else{
        System.out.println("Out of range! Pick a number that's in the list please");//prevents crashes from entering a number smaller than 0, greater than the array size
        i--;//counts back the loop in case there's a weird input from the user
      }      
      System.out.println("Team:"+team);//prints your team
      
    }
    System.out.println("Choose the fighter from your team:");
    for (int i=0;i<4;i++){
      System.out.println((i+1)+". "+team.get(i));  //prints your team out
    }
    
    int firstpoke=(kb.nextInt()-1);//lets you pick your first pokemon
    int myEnergy=50;
    Pokemon current=team.get(firstpoke);//sets your current pokemon, which from now on will be the lead of your party regardless of wether its the first one or not
    double myHp=current.hp;//sets up your hp
    int gameover=0;//sets up the gameover counter, if you lose it ticks to one and stops the game. if you choose to playtest this you'll be seeing that number tick to 1 a lot.
    while(allpoke.size()>0 && gameover!=1){
      int dead=0;//used for resetting your oponent when one of them dies
      Pokemon enemyPoke=allpoke.get(0);//sets up enemyPoke, your oponent
      
      double enemyhp=allpoke.get(0).hp;
      int enemyEnergy=50;
      
      int firstTurn=randint(1,2);//first turn is ramdonly chosen, should be an exact 50/50 if machine bias isn't a thing
      int turn=0;//starts the int for turn, will never be 0 again
      
      if (firstTurn==1){turn=1;}//if the rng lands on 1, enemy goes first
      else {turn=2;}//otherwise the player gets the advantage
      
      if (myHp+20>current.hp){myHp=current.hp;}//prevents health overflow from healing after knockouts
      else {myHp+=20;}//heals you after a knockout
      int allystun=0;//readies counters for the stun special move
      int enemystun=0;
      int allydisabled=0;//counters for the disable feature
      int enemydisabled=0;
      while (dead!=1){//turns off the battle when someone dies
        if (turn==1){//enemy's turn
          if (enemyEnergy>50){enemyEnergy=50;}//prevents energy overflow
            
            allystun=0;//unstuns your pokemon once your turn is over
            if (enemydisabled==1){//this heals instead of reducing damage, effectively reducing damage dealt by 10 one way or another
             myHp+=10;//doing a proper disable would force me to redo all the combat, not enough time unfortunately 
            }
          if (enemystun==1){//checks if the enemy is stunned
            System.out.println(enemyPoke+" is stunned!");//displays it
            enemyEnergy+=10;//gives them the energy they deserve(would be getting this by doing the one move they can do, which is doing nothing)
            turn=2;//gives the turn back to the player
          }
          if (turn==1){//i was having issues with the stunned turns but this seemingly fixed it, another check for turn order
          System.out.println(enemyPoke+"'s turn! It has "+enemyhp+"/"+enemyPoke.hp+" health left!");//enemy's name and remaning health they have energy too, but the player doesn't need to see that
          if (enemyPoke.attackcount==1){//if the cpu only has 1 attack
            if (enemyEnergy>=enemyPoke.attack1cost && !enemyPoke.attack1effect.equals("wild card") && !enemyPoke.attack1effect.equals("wild storm")){//and its not a wild card/storm since they are special
              System.out.println(enemyPoke+" uses "+enemyPoke.attack1+"!");//does the attack
              enemyEnergy-=enemyPoke.attack1cost;//removes the energy cost
              if (enemyPoke.type==current.weak){//checks for weaknesses and resistances
                System.out.println("Its super effective!");
                myHp-=(enemyPoke.attack1dam*2);//weak
                System.out.println("Dealt "+enemyPoke.attack1dam*2+" damage!");
              }
              
              else if (enemyPoke.type==current.resist){
                System.out.println("Its not very effective...");
                myHp-=(enemyPoke.attack1dam/2);//resist
                System.out.println("Dealt "+enemyPoke.attack1dam/2+" damage!");
              }
              
              else {
                myHp-=enemyPoke.attack1dam;//neutral
                System.out.println("Dealt "+enemyPoke.attack1dam+" damage!");
              }
              
              if (enemyPoke.attack1effect.equals("recharge")){//if the attack has a recharge special
                enemyEnergy+=20;//gives the oponent 20 energy back instead of 10
              }
              else{//otherwise its business as usual
                enemyEnergy+=10;
              }
              if (enemyPoke.attack1effect.equals(enemydisabled)){//if the attack has a stun special
                int stunchance=randint(1,2);//caculates the stun coinflip
                if (stunchance==2){
                  allystun=1;//and applies it
                }
              }
              if (enemyPoke.attack1effect.equals("disable")){//if the attack has the disable special effect
                allydisabled=1;
              }
             
                      
              
            }
            else if(enemyEnergy>=enemyPoke.attack1cost && enemyPoke.attack1effect.equals("wild storm")){//if the attack is a wild storm
              enemyEnergy-=enemyPoke.attack1cost; //takes out energy as usual
              int wildstorm=randint(1,2);//wildstorm coinflips
              int wilddamage=0;//damage variable, since it stacks it has to be separate from the usual attack damage
              int wildcount=0;//tells the user how lucky they got with the wild storm resets
              while (wildstorm!=1){//while the rng is in your favor (or the enemy's in this case)
                wilddamage+=enemyPoke.attack1dam;//stacks the damage
                wildcount+=1;//and the ammount of hits
                wildstorm=randint(1,2);//rerolls the rng
              }
              System.out.println(enemyPoke+" uses "+enemyPoke.attack1+"! \nWild Storm activated!");//tells users when the enemy is using a wildstorm
              
              if (enemyPoke.type==current.weak){//checks for weaknesses and resistances, same as above
                System.out.println("Its super effective!");
                myHp-=(wilddamage*2);
                System.out.println("Hit "+wildcount+" times, for "+wilddamage*2+" damage!");//but with the multiplied wildstorm damage (this can be 0!)
              }
              else if (enemyPoke.type==current.resist){
                System.out.println("Its not very effective...");
                myHp-=(wilddamage/2);
                System.out.println("Hit "+wildcount+" times, for "+wilddamage/2+" damage!");
              }
              else {
                myHp-=wilddamage;
                System.out.println("Hit "+wildcount+" times, for "+wilddamage+" damage!");
              }
              
              enemyEnergy+=10;//gives enemies the end of turn energy boost
              
              turn=2;//and passes the turn
              
            }
            else if (enemyEnergy>=enemyPoke.attack1cost && enemyPoke.attack1effect.equals("wild card")){//checks for wildcard
              enemyEnergy-=enemyPoke.attack1cost;
              int wildcard=randint(1,2); //wildcard rng
              System.out.println(enemyPoke+" uses "+enemyPoke.attack1+". Wild card activated!");//notifies users of a wildcard attack
              if (wildcard==1){
                System.out.println("Wildcard failed!");//fails and passes the turn if rng says so
                enemyEnergy+=10;
                turn=2;
              }
              else{
                if (enemyPoke.type==current.weak){//otherwise it goes through damage calculations as usual
                  System.out.println("Its super effective!");
                  myHp-=(enemyPoke.attack1dam*2);
                  System.out.println("Dealt "+enemyPoke.attack1dam*2+" damage!");
                }
                
                else if (enemyPoke.type==current.resist){
                  System.out.println("Its not very effective...");
                  myHp-=(enemyPoke.attack1dam/2);
                  System.out.println("Dealt "+enemyPoke.attack1dam/2+" damage!");
                }
                
                else {
                  myHp-=enemyPoke.attack1dam;
                  System.out.println("Dealt "+enemyPoke.attack1dam+" damage!");
                }
                
                enemyEnergy+=10;
                turn=2;
              }
            }
            else{//if they don't have energy the player is notified of that
              System.out.println(enemyPoke+" does nothing.");
              enemyEnergy+=10;//they get their 10 energy a turn
              turn=2;//and the player gets to go
              
            }
          }
          
          else if (enemyPoke.attackcount==2){//if the pokemon has 2 attacks (there needs to be segregation otherwise the program will look for fields that don't exist and crash)
            if (enemyEnergy>=enemyPoke.attack1cost && enemyEnergy>=enemyPoke.attack2cost){
              int enemyattack=randint(1,2);//ramdonly selects an attack if both are available
              if (enemyattack==1 && !enemyPoke.attack1effect.equals("wild card") && !enemyPoke.attack1effect.equals("wild storm")){//goes through damage calculations same as above
                System.out.println(enemyPoke+" uses "+enemyPoke.attack1+"!");
                
                enemyEnergy-=enemyPoke.attack1cost;
                if (enemyPoke.type==current.weak){
                  System.out.println("Its super effective!");
                  myHp-=(enemyPoke.attack1dam*2);
                  System.out.println("Dealt "+enemyPoke.attack1dam*2+" damage!");
                }
                else if (enemyPoke.type==current.resist){
                  System.out.println("Its not very effective...");
                  myHp-=(enemyPoke.attack1dam/2);
                  System.out.println("Dealt "+enemyPoke.attack1dam/2+" damage!");
                }
                else {
                  myHp-=enemyPoke.attack1dam;
                  System.out.println("Dealt "+enemyPoke.attack1dam+" damage!");
                  
                }
                if (enemyPoke.attack1effect.equals("recharge")){//checks for recharge same as the other ones
                  enemyEnergy+=20;
                }
                else{
                  enemyEnergy+=10;
                }
                
                if (enemyPoke.attack1effect.equals(enemydisabled)){//checks for stun
                  int stunchance=randint(1,2);
                  if (stunchance==2){
                    allystun=1;   
                  }
                  if (enemyPoke.attack1effect.equals("disable")){//if the attack has the disable special effect
                    allydisabled=1;
                  }
                }
                turn=2;
              }
              else if(enemyattack==1 && enemyPoke.attack1effect.equals("wild storm")){//if attack 1 has wild storm
                int wildstorm=randint(1,2);
                int wilddamage=0;
                int wildcount=0;
                while (wildstorm!=1){
                  wilddamage+=enemyPoke.attack1dam;
                  wildcount+=1;
                  wildstorm=randint(1,2);
                }
                System.out.println(enemyPoke+" uses "+enemyPoke.attack1+"! \nWild Storm activated!");
                enemyEnergy-=enemyPoke.attack1cost;
                if (enemyPoke.type==current.weak){
                  System.out.println("Its super effective!");
                  myHp-=(wilddamage*2);
                  System.out.println("Hit "+wildcount+" times, for "+wilddamage*2+" damage!");
                }
                else if (enemyPoke.type==current.resist){
                  System.out.println("Its not very effective...");
                  myHp-=(wilddamage/2);
                  System.out.println("Hit "+wildcount+" times, for "+wilddamage/2+" damage!");
                }
                else {
                  myHp-=wilddamage;
                  System.out.println("Hit "+wildcount+" times, for "+wilddamage+" damage!");
                }
                enemyEnergy+=10;
                turn=2;
                
              }
              else if (enemyattack==1 && enemyPoke.attack1effect.equals("wild card")){//iff attack 1 has wild card
                enemyEnergy-=enemyPoke.attack1cost;
                int wildcard=randint(1,2); 
                System.out.println(enemyPoke+" uses "+enemyPoke.attack1+". Wild card activated!");
                if (wildcard==1){
                  System.out.println("Wildcard failed!");
                  enemyEnergy+=10;
                  turn=2;
                }
                else{
                  if (enemyPoke.type==current.weak){
                    System.out.println("Its super effective!");
                    myHp-=(enemyPoke.attack1dam*2);
                    System.out.println("Dealt "+enemyPoke.attack1dam*2+" damage!");
                  }
                  
                  else if (enemyPoke.type==current.resist){
                    System.out.println("Its not very effective...");
                    myHp-=(enemyPoke.attack1dam/2);
                    System.out.println("Dealt "+enemyPoke.attack1dam/2+" damage!");
                  }
                  
                  else {
                    myHp-=enemyPoke.attack1dam;
                    System.out.println("Dealt "+enemyPoke.attack1dam+" damage!");
                  }
                  
                  enemyEnergy+=10;
                  turn=2;
                }
              }
              else if (enemyattack==2 && !enemyPoke.attack2effect.equals("wild card") && !enemyPoke.attack2effect.equals("wild storm")){//attack 2, works the same way as attack 1 but with different values, thanks to each pokemon's stats
                System.out.println(enemyPoke+" uses "+enemyPoke.attack2+"!");//everything from here bellow is the same as the previous instances
                enemyEnergy-=enemyPoke.attack2cost;
                if (enemyPoke.type==current.weak){
                  System.out.println("Its super effective!");
                  myHp-=(enemyPoke.attack2dam*2);
                  System.out.println("Dealt "+enemyPoke.attack2dam*2+" damage!");
                }
                else if (enemyPoke.type==current.resist){
                  System.out.println("Its not very effective...");
                  myHp-=(enemyPoke.attack2dam/2);
                  System.out.println("Dealt "+enemyPoke.attack2dam/2+" damage!");
                }
                else {
                  myHp-=enemyPoke.attack2dam;
                  System.out.println("Dealt "+enemyPoke.attack2dam+" damage!");
                }
                if (enemyPoke.attack2effect.equals("recharge")){
                  enemyEnergy+=20;
                }
                else{
                  enemyEnergy+=10;
                }
                if (enemyPoke.attack2effect.equals(enemydisabled)){
                  int stunchance=randint(1,2);
                  if (stunchance==2){
                    allystun=1;   
                  }       
                }
                if (enemyPoke.attack2effect.equals("disable")){//if the attack has the disable special effect
                  allydisabled=1;
                }
                turn=2;
              }
              else if(enemyattack==2 && enemyPoke.attack2effect.equals("wild storm")){
                int wildstorm=randint(1,2);
                int wilddamage=0;
                int wildcount=0;
                while (wildstorm!=1){
                  wilddamage+=enemyPoke.attack2dam;
                  wildcount+=1;
                  wildstorm=randint(1,2);
                }
                System.out.println(enemyPoke+" uses "+enemyPoke.attack2+"! \nWild Storm activated!");
                enemyEnergy-=enemyPoke.attack2cost;
                if (enemyPoke.type==current.weak){
                  System.out.println("Its super effective!");
                  myHp-=(wilddamage*2);
                  System.out.println("Hit "+wildcount+" times, for "+wilddamage*2+" damage!");
                }
                else if (enemyPoke.type==current.resist){
                  System.out.println("Its not very effective...");
                  myHp-=(wilddamage/2);
                  System.out.println("Hit "+wildcount+" times, for "+wilddamage/2+" damage!");
                }
                else {
                  myHp-=wilddamage;
                  System.out.println("Hit "+wildcount+" times, for "+wilddamage+" damage!");
                }
                enemyEnergy+=10;
                turn=2;
                
              }
              else if (enemyattack==2 && enemyPoke.attack2effect.equals("wild card")){
                int wildcard=randint(1,2); 
                System.out.println(enemyPoke+" uses "+enemyPoke.attack2+". Wild card activated!");
                if (wildcard==1){
                  System.out.println("Wildcard failed!");
                  enemyEnergy+=10;
                  turn=2;
                }
                else{
                  if (enemyPoke.type==current.weak){
                    System.out.println("Its super effective!");
                    myHp-=(enemyPoke.attack2dam*2);
                    System.out.println("Dealt "+enemyPoke.attack2dam*2+" damage!");
                  }
                  
                  else if (enemyPoke.type==current.resist){
                    System.out.println("Its not very effective...");
                    myHp-=(enemyPoke.attack2dam/2);
                    System.out.println("Dealt "+enemyPoke.attack2dam/2+" damage!");
                  }
                  
                  else {
                    myHp-=enemyPoke.attack2dam;
                    System.out.println("Dealt "+enemyPoke.attack2dam+" damage!");
                  }
                  
                  enemyEnergy+=10;
                  turn=2;
                }
              }
            }
            else if (enemyEnergy>=enemyPoke.attack1cost && enemyEnergy<enemyPoke.attack2cost){//if the pokemon can afford their first move, but not the second
              if (!enemyPoke.attack1effect.equals("wild storm") && !enemyPoke.attack1effect.equals("wild card")){//does the first move calculations all over again
                System.out.println(enemyPoke+" uses "+enemyPoke.attack1+"!");
                enemyEnergy-=enemyPoke.attack1cost;
                if (enemyPoke.type==current.weak){
                  System.out.println("Its super effective!");
                  myHp-=(enemyPoke.attack1dam*2);
                  System.out.println("Dealt "+enemyPoke.attack1dam*2+" damage!");
                }
                else if (enemyPoke.type==current.resist){
                  System.out.println("Its not very effective...");
                  myHp-=(enemyPoke.attack1dam/2);
                  System.out.println("Dealt "+enemyPoke.attack1dam/2+" damage!");
                }
                else {
                  myHp-=enemyPoke.attack1dam;
                  System.out.println("Dealt "+enemyPoke.attack1dam+" damage!");
                }
                if (enemyPoke.attack1effect.equals("recharge")){
                  enemyEnergy+=20;
                }
                else{
                  enemyEnergy+=10;
                }
                if (enemyPoke.attack1effect.equals(enemydisabled)){
                  int stunchance=randint(1,2);
                  if (stunchance==2){
                    allystun=1;   
                  }       
                }
                if (enemyPoke.attack1effect.equals("disable")){//if the attack has the disable special effect
                    allydisabled=1;
                  }
                turn=2;
              }
            }
            else if(enemyPoke.attack1effect.equals("wild storm")){
              int wildstorm=randint(1,2);
              int wilddamage=0;
              int wildcount=0;
              while (wildstorm!=1){
                wilddamage+=enemyPoke.attack1dam;
                wildcount+=1;
                wildstorm=randint(1,2);
              }
              System.out.println(enemyPoke+" uses "+enemyPoke.attack1+"! \nWild Storm activated!");
              enemyEnergy-=enemyPoke.attack1cost;
              if (enemyPoke.type==current.weak){
                System.out.println("Its super effective!");
                myHp-=(wilddamage*2);
                System.out.println("Hit "+wildcount+" times, for "+wilddamage*2+" damage!");
              }
              else if (enemyPoke.type==current.resist){
                System.out.println("Its not very effective...");
                myHp-=(wilddamage/2);
                System.out.println("Hit "+wildcount+" times, for "+wilddamage/2+" damage!");
              }
              else {
                myHp-=wilddamage;
                System.out.println("Hit "+wildcount+" times, for "+wilddamage+" damage!");
              }
              enemyEnergy+=10;
              turn=2;
              
            }
            else if ( enemyPoke.attack1effect.equals("wild card")){
              enemyEnergy-=enemyPoke.attack1cost;
              int wildcard=randint(1,2); 
              System.out.println(enemyPoke+" uses "+enemyPoke.attack1+". Wild card activated!");
              if (wildcard==1){
                System.out.println("Wildcard failed!");
                enemyEnergy+=10;
                turn=2;
              }
              else{
                if (enemyPoke.type==current.weak){
                  System.out.println("Its super effective!");
                  myHp-=(enemyPoke.attack1dam*2);
                  System.out.println("Dealt "+enemyPoke.attack1dam*2+" damage!");
                }
                
                else if (enemyPoke.type==current.resist){
                  System.out.println("Its not very effective...");
                  myHp-=(enemyPoke.attack1dam/2);
                  System.out.println("Dealt "+enemyPoke.attack1dam/2+" damage!");
                }
                
                else {
                  myHp-=enemyPoke.attack1dam;
                  System.out.println("Dealt "+enemyPoke.attack1dam+" damage!");
                }
                
                enemyEnergy+=10;
                turn=2;
              }
            }
            
            else if (enemyEnergy<enemyPoke.attack1cost &&enemyEnergy>=enemyPoke.attack2cost){//if the pokemon can afford their second move, but not the first
              System.out.println(enemyPoke+" uses "+enemyPoke.attack2+"!");//does the calculations again
              if (enemyPoke.type==current.weak){
                System.out.println("Its super effective!");
                myHp-=(enemyPoke.attack2dam*2);
                System.out.println("Dealt "+enemyPoke.attack2dam*2+" damage!");
              }
              else if (enemyPoke.type==current.resist){
                System.out.println("Its not very effective...");
                myHp-=(enemyPoke.attack2dam/2);
                System.out.println("Dealt "+enemyPoke.attack2dam/2+" damage!");
              }
              else {
                myHp-=enemyPoke.attack2dam;
                System.out.println("Dealt "+enemyPoke.attack2dam+" damage!");
              }
              if (enemyPoke.attack2effect.equals("recharge")){
                enemyEnergy+=20;
              }
              else{
                enemyEnergy+=10;
              }
              if (enemyPoke.attack2effect.equals(enemydisabled)){
                int stunchance=randint(1,2);
                if (stunchance==2){
                  allystun=1;   
                }       
              }
              if (enemyPoke.attack2effect.equals("disable")){//if the attack has the disable special effect
                allydisabled=1;
              }
              turn=2;
              
            }
            else if(enemyPoke.attack2effect.equals("wild storm")){
              int wildstorm=randint(1,2);
              int wilddamage=0;
              int wildcount=0;
              while (wildstorm!=1){
                wilddamage+=enemyPoke.attack2dam;
                wildcount+=1;
                wildstorm=randint(1,2);
              }
              System.out.println(enemyPoke+" uses "+enemyPoke.attack2+"! \nWild Storm activated!");
              enemyEnergy-=enemyPoke.attack2cost;
              if (enemyPoke.type==current.weak){
                System.out.println("Its super effective!");
                myHp-=(wilddamage*2);
                System.out.println("Hit "+wildcount+" times, for "+wilddamage*2+" damage!");
              }
              else if (enemyPoke.type==current.resist){
                System.out.println("Its not very effective...");
                myHp-=(wilddamage/2);
                System.out.println("Hit "+wildcount+" times, for "+wilddamage/2+" damage!");
              }
              else {
                myHp-=wilddamage;
                System.out.println("Hit "+wildcount+" times, for "+wilddamage+" damage!");
              }
              enemyEnergy+=10;
              turn=2;
              
            }
            else if (enemyPoke.attack2effect.equals("wild card")){
              int wildcard=randint(1,2); 
              System.out.println(enemyPoke+" uses "+enemyPoke.attack2+". Wild card activated!");
              if (wildcard==1){
                System.out.println("Wildcard failed!");
                enemyEnergy+=10;
                turn=2;
              }
              else{//but if it can't afford either of them
                System.out.println(enemyPoke+" does nothing.");//does nothing
                enemyEnergy+=10;//adds the 10-per-turn energy
                turn=2;//and passes it to the player
              }
              
            }
          }
        }
          if (gameover==1){//gameover loop breaker, in here to prevent infinite loops and/or crashes
           System.out.println("Game Over!");//prints a very familiar message
           break;//and stops the loops
          }
        }
        
        
        
        else if (turn==2){//if its the player's turn
          if (myEnergy>50){myEnergy=50;}//prevents energy overflow
          enemystun=0;//unstuns the enemy
            if (allystun==1){//shows the player they are stunned, gives them energy and ends their turn
              System.out.println("You're stunned!");
              if (allydisabled==1){//same explanation as above, not enough time to do a proper disable
                enemyhp+=10;//heals instead
              }
              myEnergy+=10;
              
              turn=1;
            }
            if (turn==2){//checking for the turn twice, to prevent the same crashes as above, all caused by the stun mechanic
            
          if (current.attackcount==1){//if the player's pokemon has only 1 attack
            System.out.println("Your oponent is "+enemyPoke+"! It has "+enemyhp+"/"+enemyPoke.hp+" Hp. \nYour Pokemon is "+current+" and you have "+myHp+"/"+current.hp+" HP and "+myEnergy+"/50"+" energy. \nChoose your command: \n 1. "+current.attack1+", Dmg: "+current.attack1dam+", Cost: "+current.attack1cost+" Effect: "+current.attack1effect);
            System.out.println(" 2. Retreat. \n 3. Pass.");//gives the players their commands. i might have made it too long but you can see what it looks like in game. very neat all things considered
            int action=kb.nextInt();//gets your input for your pokemon's action
            if(action==1 && myEnergy>= current.attack1cost && !current.attack1effect.equals("wild storm") && !current.attack1effect.equals("wild card")){//checks if their only attack does not have wildstorm/card and if you can afford to use it
              System.out.println("Your "+current+" uses "+current.attack1+"!");//displays that you are using said attack
              myEnergy-=current.attack1cost;//takes away the energy cost of the attack
              if (current.type==enemyPoke.weak){//and calculates the weaknesses, same as with the enemy attacks
                System.out.println("Its super effective!");
                enemyhp-=(current.attack1dam*2);
                
              }
              else if (current.type==enemyPoke.resist){
                System.out.println("Its not very effective...");
                enemyhp-=(current.attack1dam/2);
                
              }
              else {
                enemyhp-=current.attack1dam;
              }
              if (current.attack1effect.equals("recharge")){//checks for recharge specials, as usual
                myEnergy+=20;
              }
              else{
                myEnergy+=10;
              }
              if (current.attack1effect.equals(enemydisabled)){//checks for stun specials
                int stunchance=randint(1,2);
                if (stunchance==2){
                  enemystun=1;   
                }
              }
              if (current.attack1effect.equals("disable")){//check for disable specials
                enemydisabled=1;
              }
              turn=1;
            }
            
            else if(action==1 && current.attack1effect.equals("wild storm")&& myEnergy>=current.attack1cost){//checks if you can afford the attack and if its got a wild storm special
              int wildstorm=randint(1,2);//calculations for wild storm loops are the exact same
              int wilddamage=0;
              int wildcount=0;
              while (wildstorm!=1){
                wilddamage+=current.attack1dam;
                wildcount+=1;
                wildstorm=randint(1,2);
              }
              System.out.println("Your "+current+" uses "+current.attack1+"! Wild Storm activated!");//displays the move you're using
              myEnergy-=current.attack1cost;//takes away the energy cost
              if (current.type==enemyPoke.weak){
                System.out.println("You hit "+wildcount+" times! Its super effective!\n"+wilddamage+" damage dealt!");//and does the special wildstorm damage calculations
                enemyhp-=(wilddamage*2);
                
              }
              else if (current.type==enemyPoke.resist){
                System.out.println("You hit "+wildcount+" times! Its not very effective...\n"+wilddamage+" damage dealt!");
                enemyhp-=(wilddamage/2);
                
              }
              else {
                enemyhp-=wilddamage;
                System.out.println("You hit "+wildcount+" times for "+wilddamage+" damage.");
              }
              myEnergy+=10;
              turn=1;
              
            }
            
            else if (myEnergy>=current.attack1cost && current.attack1effect.equals("wild card")){//same for wild card, business as usual but using the player's attacks instead of the enemy's
              myEnergy-=current.attack1cost;
              int wildcard=randint(1,2); 
              System.out.println(current+" uses "+current.attack1+". Wild card activated!");
              if (wildcard==1){
                System.out.println("Wildcard failed!");
                myEnergy+=10;
                turn=1;
              }
              else{
                if (current.type==enemyPoke.weak){
                  System.out.println("Its super effective!");
                  enemyhp-=(current.attack1dam*2);
                  
                }
                else if (current.type==enemyPoke.resist){
                  System.out.println("Its not very effective...");
                  enemyhp-=(current.attack1dam/2);
                  
                }
                else {
                  enemyhp-=current.attack1dam;
                }
                myEnergy+=10;
                turn=1;
              } 
            }
            else if(action==1 && myEnergy<current.attack1cost){
              System.out.println("Not enough energy!");
            }
            
            
            else if (action==2){//lets you change your active pokemon
              int pick=0;//prepares your pick
              int changeHp=0;//and the hp of the new pokemon that's being swapped in
              while (pick!=1){//while you haven't made your pick
                for (int i=0;i<team.size();i++){
                  System.out.println((i+1)+". "+team.get(i));//displays the rest of your team
                }
                System.out.println("Pick your pokemon");
                int newpoke=kb.nextInt();//goes through each pick, changing them accordingly and replaces your current pokemon with your new one
                if (newpoke==1){
                  current=team.get(newpoke-1);
                  changeHp=1;
                  pick=1;//and ends the pick loop
                  
                }
                else if (newpoke==2 && team.size()>=2){//important that you pick a number that's still in your team
                  current=team.get(newpoke-1);
                  changeHp=1;
                  pick=1;
                }
                else if (newpoke==3 && team.size()>=3){
                  current=team.get(newpoke-1); 
                  changeHp=1;
                  pick=1;
                }
                else if( newpoke==0){pick=1;}//ends your turn without switching
                
                else{System.out.println("Out of range!");}//or tells you to go again if the pokemon you picked doesns't exist
              }
              if (changeHp==1){
                myHp=current.hp;//changes the hps accordingly
              }
              turn=1;//passes your turn
            }
            
            else if (action==3){//idle command for when you don't have energy, you've seent this before
              System.out.println(current+" does nothing!");
              myEnergy+=10;
              turn=1;
            }
            
          }
          else{//if your pokemon has more than one move
            System.out.println("Your Pokemon is "+current+" and you have "+myHp+"/"+current.hp+" HP and "+myEnergy+"/50"+" energy. \nChoose your command: \n 1. "+current.attack1+", Dmg: "+current.attack1dam+", Cost: "+current.attack1cost+", Effect: "+current.attack1effect);
            System.out.println(" 2. "+current.attack2+", Dmg: "+current.attack2dam+", Cost: "+current.attack2cost+", Effect: "+current.attack2effect);//bigger menus since you have 2 attacks to pick from. see it in game!
            System.out.println(" 3. Retreat. \n 4. Pass.");//did 3 separate print statements for visibility, basically so that you don't have to scroll all the way to the side to see what im doing
            
            int action=kb.nextInt();//gets your next input
            if(action==1 && myEnergy>= current.attack1cost && !current.attack1effect.equals("wild storm") && !current.attack1effect.equals("wild card")){//goes through attacks the same way as before, but there's 2 now
              System.out.println("Your "+current+" uses "+current.attack1+"!");
              myEnergy-=current.attack1cost;
              if (current.type==enemyPoke.weak){
                System.out.println("Its super effective!");
                enemyhp-=(current.attack1dam*2);
                
              }
              else if (current.type==enemyPoke.resist){
                System.out.println("Its not very effective...");
                enemyhp-=(current.attack1dam/2);
                
              }
              else {
                enemyhp-=current.attack1dam;
              }
              if (current.attack1effect.equals("recharge")){
                myEnergy+=20;
              }
              else{
                myEnergy+=10;
              }
              if (current.attack1effect.equals(enemydisabled)){
                int stunchance=randint(1,2);
                if (stunchance==2){
                  enemystun=1;   
                }
              }
              if (current.attack1effect.equals("disable")){
                enemydisabled=1;
              }
              turn=1;
            }
            else if(action==1 && myEnergy<current.attack1cost){
              System.out.println("Not enough energy!");
            }
            else if(action==1 && current.attack1effect.equals("wild storm")){
              int wildstorm=randint(1,2);
              int wilddamage=0;
              int wildcount=0;
              while (wildstorm!=1){
                wilddamage+=current.attack1dam;
                wildcount+=1;
                wildstorm=randint(1,2);
              }
              System.out.println("Your "+current+" uses "+current.attack1+"! Wild Storm activated!");
              myEnergy-=current.attack1cost;
              if (current.type==enemyPoke.weak){
                System.out.println("You hit "+wildcount+" times! Its super effective!\n"+wilddamage+" damage dealt!");
                enemyhp-=(wilddamage*2);
                
              }
              else if (current.type==enemyPoke.resist){
                System.out.println("You hit "+wildcount+" times! Its not very effective...\n"+wilddamage+" damage dealt!");
                enemyhp-=(wilddamage/2);
                
              }
              else {
                enemyhp-=wilddamage;
                System.out.println("You hit "+wildcount+" times for "+wilddamage+" damage.");
              }
              myEnergy+=10;
              turn=1;
              
            }
            else if (myEnergy>=current.attack1cost && current.attack1effect.equals("wild card")){
              myEnergy-=current.attack1cost;
              int wildcard=randint(1,2); 
              System.out.println(current+" uses "+current.attack1+". Wild card activated!");
              if (wildcard==1){
                System.out.println("Wildcard failed!");
                myEnergy+=10;
                turn=1;
              }
              else{
                if (current.type==enemyPoke.weak){
                  System.out.println("Its super effective!");
                  enemyhp-=(current.attack1dam*2);
                  
                }
                else if (current.type==enemyPoke.resist){
                  System.out.println("Its not very effective...");
                  enemyhp-=(current.attack1dam/2);
                  
                }
                else {
                  enemyhp-=current.attack1dam;
                }
                myEnergy+=10;
                turn=1;
              } 
            }
            
            else if (action==2 && myEnergy>=current.attack2cost && !current.attack2effect.equals("wild storm") && !current.attack2effect.equals("wild card")){
              System.out.println("Your "+current+" uses "+current.attack2+"!");
              myEnergy-=current.attack2cost;
              if (current.type==enemyPoke.weak){
                System.out.println("Its super effective!");
                enemyhp-=(current.attack2dam*2);
                
              }
              else if (current.type==enemyPoke.resist){
                System.out.println("Its not very effective...");
                enemyhp-=(current.attack2dam/2);
                
              }
              else {
                enemyhp-=current.attack2dam;
              }
              if (current.attack2effect.equals("recharge")){
                myEnergy+=20;
              }
              else{
                myEnergy+=10;
              }
              if (current.attack2effect.equals(enemydisabled)){
                int stunchance=randint(1,2);
                if (stunchance==2){
                  enemystun=1;   
                }
              }
              if (current.attack2effect.equals("disable")){
                enemydisabled=1;
              }
              turn=1;
            }
            else if(action==2 && myEnergy<current.attack2cost){
              System.out.println("Not enough energy!");
            }
            else if(action==2 && current.attack2effect.equals("wild storm")){
              int wildstorm=randint(1,2);
              int wilddamage=0;
              int wildcount=0;
              while (wildstorm!=1){
                wilddamage+=current.attack2dam;
                wildcount+=1;
                wildstorm=randint(1,2);
              }
              System.out.println("Your "+current+" uses "+current.attack2+"! Wild Storm activated!");
              myEnergy-=current.attack2cost;
              if (current.type==enemyPoke.weak){
                System.out.println("You hit "+wildcount+" times! Its super effective!\n"+wilddamage+" damage dealt!");
                enemyhp-=(wilddamage*2);
                
              }
              else if (current.type==enemyPoke.resist){
                System.out.println("You hit "+wildcount+" times! Its not very effective...\n"+wilddamage+" damage dealt!");
                enemyhp-=(wilddamage/2);
                
              }
              else {
                enemyhp-=wilddamage;
                System.out.println("You hit "+wildcount+" times for "+wilddamage+" damage.");
              }
              myEnergy+=10;
              turn=1;
              
            }
            else if (myEnergy>=current.attack2cost && current.attack2effect.equals("wild card")){
              myEnergy-=current.attack2cost; 
              int wildcard=randint(1,2); 
              System.out.println(current+" uses "+current.attack2+". Wild card activated!");
              if (wildcard==1){
                System.out.println("Wildcard failed!");
                myEnergy+=10;
                turn=1;
              }
              else{
                if (current.type==enemyPoke.weak){
                  System.out.println("Its super effective!");
                  enemyhp-=(current.attack2dam*2);
                  
                }
                else if (current.type==enemyPoke.resist){
                  System.out.println("Its not very effective...");
                  enemyhp-=(current.attack2dam/2);
                  
                }
                else {
                  enemyhp-=current.attack2dam;
                }
                myEnergy+=10;
                turn=1;
              } 
            }
            
            
            
            else if (action==3){
              int pick=0;
              int changeHp=0;
              while (pick!=1){
                for (int i=0;i<team.size();i++){
                  System.out.println((i+1)+". "+team.get(i));
                }
                System.out.println("Pick your pokemon");
                int newpoke=kb.nextInt();
                if (newpoke==1){
                  current=team.get(newpoke-1);
                  changeHp=1;
                  pick=1;
                  
                }
                else if (newpoke==2 && team.size()>=2){
                  current=team.get(newpoke-1);
                  changeHp=1;
                  pick=1;
                }
                else if (newpoke==3 && team.size()>=3){
                  current=team.get(newpoke-1); 
                  changeHp=1;
                  pick=1;
                }
                else if( newpoke==0){pick=1;}
                
                else{System.out.println("Out of range!");}
              }
              if (changeHp==1){
                myHp=current.hp;
              }
              turn=1;
            }
            
            else if (action==3){
              System.out.println(current+" does nothing!");
              myEnergy+=10;
              turn=1;
            }
            
            else if (action==4){
              System.out.println(current+" does nothing!");
              myEnergy+=10;
              turn=1;
            }
            
          }
        }
        }
        if (enemyhp<=0){//if the enemy is defeated
          System.out.println(enemyPoke+" fainted!");//displays a message
          allpoke.remove(allpoke.get(allpoke.indexOf(enemyPoke)));//removes it from the arraylist
          enemyPoke=allpoke.get(0);//gives you a new opponent
          System.out.println("Your next oponent is "+enemyPoke+"!"); //shows users their next challanger
          dead=1;//and goes through the original set up again, minus the random turn order
        }
        if (myHp<=0 && team.size()>1){//whenever one of your pokemon dies
          System.out.println(current+" fainted! Choose your next Pokemon");//displays that fact
          team.remove(current);//removes them from your team
          int pick=0;//and goes through the swapping out process again, only this time you can't quit out
          while (pick!=1){
            for (int i=0;i<team.size();i++){
              System.out.println((i+1)+". "+team.get(i));  
            }
            int newpoke=kb.nextInt();
            if (newpoke==1){
              current=team.get(newpoke-1);
              pick=1;
            }
            else if (newpoke==2 && team.size()>=2){
              current=team.get(newpoke-1);
              pick=1;
            }
            else if (newpoke==3 && team.size()>=3){
              current=team.get(newpoke-1); 
              pick=1;
            }
            else{System.out.println("Out of range!");}
          }
          myEnergy=50;//resets your energy
          myHp=current.hp;//and your hp
          
          
          
        }
        else if (myHp<=0 && team.size()<=1) {//checks when all your pokemon are dead
          System.out.println("You lose!");//prints a friendly message
          gameover=1;//ends the game
          break;//and closes the array
        }
        
        
      }
    }
    
    
    
    
    if (gameover!=1){//if you somehow beat the 24 remaning pokemon
      System.out.println("You win! Did you get lucky or what? This game is supposed to be almost unbeatable!"); //gives you a fun message
    }
  }
  
  public static int randint(int low, int high){//randint function i've been using
    return (int)(Math.random()*(high-low+1) + low);//speeds up getting random integers a little bit, just a nice timesaver
  }
}


